package bot

// API Chat ships with a small editable data deck (persona + share + fallback).
// Files are seeded into data/api_chat only when missing, so a user's edits are
// never overwritten by an app update.

import (
	"embed"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
)

//go:embed api_assets/README.txt api_assets/persona.txt api_assets/persona_countries.txt api_assets/sharesnap.txt api_assets/share.txt api_assets/fallback.txt
var apiChatAssets embed.FS

// EnsureAPIChatData creates data/api_chat and restores any missing starter
// file. It returns the runtime folder path.
func EnsureAPIChatData(dataDir string) (string, error) {
	root := filepath.Join(dataDir, "api_chat")
	if err := os.MkdirAll(root, 0o755); err != nil {
		return "", fmt.Errorf("create API Chat data directory: %w", err)
	}
	err := fs.WalkDir(apiChatAssets, "api_assets", func(assetPath string, entry fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if assetPath == "api_assets" || entry.IsDir() {
			return nil
		}
		rel := strings.TrimPrefix(assetPath, "api_assets/")
		destination := filepath.Join(root, filepath.FromSlash(rel))
		if _, err := os.Stat(destination); err == nil {
			return nil
		} else if !os.IsNotExist(err) {
			return err
		}
		data, err := apiChatAssets.ReadFile(assetPath)
		if err != nil {
			return err
		}
		return os.WriteFile(destination, data, 0o644)
	})
	if err != nil {
		return "", fmt.Errorf("bootstrap API Chat starter data: %w", err)
	}
	return root, nil
}

// readAPILines reads a small TXT deck: one entry per line, blank lines and
// lines starting with # are ignored.
func readAPILines(path string) ([]string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	var out []string
	for _, line := range strings.Split(strings.ReplaceAll(string(data), "\r\n", "\n"), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		out = append(out, line)
	}
	return out, nil
}
