package apichat

// Goal ladder: every reply has a stage and a single goal. The stage keeps the
// conversation moving toward the snap instead of drifting in small talk.

// Stage is where the funnel currently is.
type Stage string

const (
	StageRapport  Stage = "rapport"
	StageInterest Stage = "interest"
	StageHook     Stage = "hook"
	StageAsk      Stage = "ask"
	StageShare    Stage = "share"
	StageClose    Stage = "close"
)

// stageFor derives the stage from the director state and the configured turn.
func stageFor(d *Director, turn, target int) Stage {
	switch {
	case d.Shared:
		return StageClose
	case d.AskedSnap:
		return StageAsk
	case turn <= 2:
		return StageRapport
	case turn >= target-2:
		return StageHook
	}
	return StageInterest
}

// stageGoal is the one-line objective handed to the model for this reply.
func stageGoal(stage Stage, p MessageProfile) string {
	switch stage {
	case StageRapport:
		return "make them comfortable, react to their message, learn one small thing about them"
	case StageInterest:
		if topic := firstChatTopic(p.Topics); topic != "" {
			return "show you get them, then dig into " + topicHint(topic)
		}
		return "show you get them, keep them talking about themselves"
	case StageHook:
		return "keep the vibe, drop one casual hint that you barely use this app"
	case StageAsk:
		return "keep it light and ask if they have snap, one line only"
	case StageShare:
		return "send the snap username casually and move the chat there"
	case StageClose:
		return "close warmly: ttyl, or say you will accept their add"
	}
	return "react to what they said"
}

func firstChatTopic(topics []string) string {
	for _, topic := range topics {
		if chattableTopic(topic) {
			return topic
		}
	}
	return ""
}
